import GreenDesignerPage from '../GreenDesignerPage'

export default function GreenDesignerPageExample() {
  return <GreenDesignerPage />
}
