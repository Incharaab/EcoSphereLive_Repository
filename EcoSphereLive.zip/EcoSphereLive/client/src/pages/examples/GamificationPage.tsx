import GamificationPage from '../GamificationPage'

export default function GamificationPageExample() {
  return <GamificationPage />
}
