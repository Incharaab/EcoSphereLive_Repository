import DashboardPage from '../DashboardPage'

export default function DashboardPageExample() {
  return <DashboardPage />
}
